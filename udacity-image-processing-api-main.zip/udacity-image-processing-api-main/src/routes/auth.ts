import express from 'express';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';
import client from '../database';

const router = express.Router();

router.post('/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        const result = await client.query('SELECT * FROM users WHERE username = $1', [username]);
        const user = result.rows[0];

        if (user && await bcrypt.compare(password, user.password)) {
            const token = jwt.sign({ username: user.username }, process.env.JWT_SECRET as string, { expiresIn: '1h' });
            res.json({ token });
        } else {
            res.status(401).send('Username or password incorrect');
        }
    } catch (err) {
        res.status(500).send('Internal server error');
    }
});

export default router;