const dotenv = require('dotenv');
const { Pool } = require('pg');

dotenv.config()

// Pgsql config
const {
    POSTGRES_HOST,
    POSTGRES_DB,
    POSTGRES_USER,
    POSTGRES_PASSWORD,
    POSTGRES_SCHEMA
} = process.env

const client = new Pool({
    host: POSTGRES_HOST,
    database: POSTGRES_DB,
    user: POSTGRES_USER,
    password: POSTGRES_PASSWORD,
    options: `-c search_path=${POSTGRES_SCHEMA}`
})

export default client;