import express = require('express');
import cors = require('cors');
import product_routes from '../src/handle/products';
import authenticateJWT from './middleware/auth';
import authRouter from './routes/auth';

const app = express();
const port = 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(cors());

product_routes(app);

app.use('/auth', authRouter);
app.use(authenticateJWT);

app.listen(port, () => {
    console.log(`Server started at localhost:${port}`);
});